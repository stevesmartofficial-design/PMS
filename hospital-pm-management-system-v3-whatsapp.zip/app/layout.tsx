import "./globals.css";
export const metadata={title:"Preventive Maintenance Management"};
export default function Layout({children}:{children:React.ReactNode}){return <html><body>{children}</body></html>}
