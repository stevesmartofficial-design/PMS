import PMApp from "./ui/PMApp";
export default function Page(){return <PMApp/>}
