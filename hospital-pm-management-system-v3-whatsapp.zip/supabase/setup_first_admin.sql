insert into public.users(id,full_name,role_id)
select 'YOUR-USER-UUID','Hospital Administrator',id from public.roles where name='SUPER ADMIN'
on conflict(id) do update set full_name=excluded.full_name,role_id=excluded.role_id;